# DONATING

Found this project helpful and want to give a support by donating?

[![Donate with PayPal](paypal.svg)](https://www.paypal.me/nrmuhammad)

Or donate directly to my bank account below.

- Bank name: **Bank Mandiri** [ code: 008 ]
- Account number: **161-00-0140973-4**
- Receiver name: **Nur Muhammad**

For international transfer purpose, you may needs this information also:

- Receiver bank name: **PT. Bank Mandiri (Persero) Tbk**
- Address: **Plaza Mandiri Jl Gatot Subroto Kav 36-38 Jakarta 12190**
- SWIFT code: **BMRIIDJA**

Feel free to [contact me by Whatsapp](https://wa.me/6287864423038). Maybe for the transfer confirmation, so I know about your support.

Thanks in advance.
